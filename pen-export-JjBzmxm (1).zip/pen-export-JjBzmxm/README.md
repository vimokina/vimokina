# Резюме

A Pen created on CodePen.io. Original URL: [https://codepen.io/vimokina/pen/JjBzmxm](https://codepen.io/vimokina/pen/JjBzmxm).

